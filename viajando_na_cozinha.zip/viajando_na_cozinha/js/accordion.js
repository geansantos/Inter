
 $(function() {
   $( "#accordion" ).accordion();
 });